package org.usfirst.frc.team6451.robot;

import edu.wpi.cscore.UsbCamera;
import edu.wpi.cscore.VideoSink;
import edu.wpi.first.wpilibj.*;

public class Robot extends IterativeRobot {

	Joystick driveStick = new Joystick(0);
	RobotDrive roboDrive = new RobotDrive(0, 1);
	Victor combine = new Victor(2);
	Victor elevator = new Victor(3);
	Victor shooter = new Victor(4);
	Victor agitator = new Victor(6);
	Victor winch = new Victor(7);
	CameraServer camServer = CameraServer.getInstance();
	//UsbCamera pickerCam = new UsbCamera("picker", 0);
	//UsbCamera gearCam = new UsbCamera("gear", 1);

	boolean pickerBool = true;
	boolean shooterBool = false;
	boolean agitatorBool = false;
	boolean driveForward = true;

	// -1 = forward, 1 = backward
	int driveDirection = -1;

	@Override
	public void robotInit() {
		camServer.startAutomaticCapture("Gear", 1);
		camServer.startAutomaticCapture("Picker", 0);
		//camServer.addCamera(pickerCam);
		//camServer.addCamera(gearCam);
		//camServer.getVideo(pickerCam);
	}

	@Override
	public void autonomousInit() {

		// shooting autonomous (probably doesn't work anymore)
		/*DriverStation.Alliance color;
		color = DriverStation.getInstance().getAlliance();
		if (color == DriverStation.Alliance.Red) {
			shooter.set(.75);// .725
			ManualDrive(.75, 0, .7);
			ManualDrive(0, .653, 1.1);
			ManualDrive(.6, 0, .85);
			agitator.setSpeed(-.8);
			Timer.delay(12.155);
			shooter.stopMotor();
			agitator.stopMotor();
		} else if (color == DriverStation.Alliance.Blue) {
			shooter.set(.75);// .725
			ManualDrive(.75, 0, .9);
			ManualDrive(0, -.775, .765);
			ManualDrive(.6, 0, 1.18);
			agitator.setSpeed(-.8);
			Timer.delay(12.155);
			shooter.stopMotor();
			agitator.stopMotor();
		}*/

		// cross baseline
		ManualDrive(-.45, 0, 7);

		// baseline
		//ManualDrive(-.675, 0, 2.45);
		//old -.45, 0, 3.3
		
		//ManualDrive(-.45, 0, 3.45);
		
		//shooter
		/*shooter.setSpeed(.775);
		Timer.delay(.45);
		agitator.setSpeed(.9);*/

	}

	@Override
	public void autonomousPeriodic() {
	}

	@Override
	public void teleopInit() {
	}

	@Override
	public void teleopPeriodic() {

		// drive
		// roboDrive.arcadeDrive(Math.asin(-1 * driveStick.getRawAxis(1)),
		// Math.asin(-1 * driveStick.getRawAxis(0)));
		roboDrive.arcadeDrive(Math.asin(driveDirection * driveStick.getRawAxis(1)), Math.asin(-1 * driveStick.getRawAxis(0)));

		// toggle code
		if (pickerBool) {
			combine.setSpeed(-.35);
			elevator.setSpeed(.85);
		} else {
			combine.stopMotor();
			elevator.stopMotor();
		}

		if (agitatorBool) {
			agitator.setSpeed(.9);
		} else {
			agitator.stopMotor();
		}

		// toggle buttons

		// toggles agitator
		if (driveStick.getRawButton(1)) {
			
			if (agitatorBool) {
				agitatorBool = false;
				log("Agitator Disabled");
				Timer.delay(.2);
			} else {
				agitatorBool = true;
				log("Agitator Enabled");
				Timer.delay(.2);
			}
			
			/*
			//String agitator_state = (agitatorBool) ? "Disabled" : "Enabled";
			agitatorBool = !agitatorBool;
			//log("Agitator " + agitator_state + "!");
			if (agitatorBool) log("Agitator enabled!");
			else log("Agitator disabled!");
			Timer.delay(.2);
			*/
		}

		// toggles picker
		if (driveStick.getRawButton(3)) {
			if (pickerBool) {
				pickerBool = false;
				log("Picker Disabled");
				Timer.delay(.2);
			} else {
				pickerBool = true;
				log("Picker Enabled");
				Timer.delay(.2);
			}
		}

		// toggles drive direction
		if (driveStick.getRawButton(3)) {
			if (driveForward) {
				driveForward = false;
				driveDirection = 1;
				log("Driving Backwards");
				Timer.delay(.2);
			} else {
				driveForward = true;
				driveDirection = -1;
				log("Driving Forward");
				Timer.delay(.2);
			}
		}

		// winch speed
		setWinch(driveStick.getRawAxis(3));
		// winch.setSpeed(-1);

		// shooter speed
		setShooter();

	}

	@Override
	public void testPeriodic() {
	}

	public void setWinch(double throttle) {
		// sets from 0 to -1(-1 is full)
		throttle -= 1;
		throttle /= 2;

		winch.setSpeed(throttle);
		if (throttle < -.1) {
			log("Winch Enabled at " + winch.getSpeed());
		}
	}

	public void setShooter() {

		// sets shooter speed with side buttons
		if (driveStick.getRawButton(7)) {
			shooter.setSpeed(.5);
			log("Shooter Enabled at 75%");
		}
		if (driveStick.getRawButton(8)) {
			shooter.setSpeed(.6);
			log("Shooter Enabled at 77.5%");
		}
		if (driveStick.getRawButton(9)) {
			shooter.setSpeed(.7);
			log("Shooter Enabled at 80%");
		}
		if (driveStick.getRawButton(10)) {
			shooter.setSpeed(.8);
			log("Shooter Enabled at 82.5%");
		}
		if (driveStick.getRawButton(11)) {
			shooter.setSpeed(.9);
			log("Shooter Enabled at 85%");
		}
		if (driveStick.getRawButton(12)) {
			shooter.setSpeed(.99);
			log("Shooter Enabled at 87.5%");
		}
		if (driveStick.getRawButton(2)) {
			shooter.stopMotor();
			log("Shooter Disabled");
		}
	}

	@SuppressWarnings("static-access")
	public void ManualDrive(double ForwardSpeed, double TurnSpeed, double sec) {
		sec = sec * 100;
		TurnSpeed *= -1;
		for (int i = 0; i < sec; i++) {
			roboDrive.arcadeDrive(ForwardSpeed, TurnSpeed);
			Timer.delay(0.01);
		}
		roboDrive.stopMotor();
	}

	public void log(String message) {
		DriverStation.reportError(message, false);
		// System.out.println(message);
	}
}